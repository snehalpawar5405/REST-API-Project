package main

const dbName = "product"
const dbuser = "root"
const dbpassword = "SauMar#123"
