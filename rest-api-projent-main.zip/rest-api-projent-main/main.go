package main

func main() {
	app := App{}
	app.Initialise()
	app.run("localhost:10000")
}
